// (c) 2017 Valter Foresto
   
var app = {

    debug: true,
    localDebug: true, 
    listItem: "",
    advMAC: "",
    advItem: "",
    advTimer: 0,
    AIN0um: "mV",
    minAIN0um: 0,
    maxAIN0um: 1240,
    AIN1um: "mV",
    minAIN1um: 0,
    maxAIN1um: 1240,
    k0: 0.60546875,
    k1: 0.60546875,
    a: "",
    b: "",
    node: {
      service:      "EE0C1000-8786-40BA-AB96-99B91AC981D8",
      relay:        "EE0C1011-8786-40BA-AB96-99B91AC981D8",
      led1:         "EE0C1012-8786-40BA-AB96-99B91AC981D8",
      led2:         "EE0C1013-8786-40BA-AB96-99B91AC981D8",
      out0:         "EE0C1014-8786-40BA-AB96-99B91AC981D8",
    },  
    value: "",
    
    initialize: function() {
      if(app.debug) console.log("initialize()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "initialize()";
      homePage.hidden = true;
      infoPage.hidden = true;
      docPage.hidden = true;
      dataPage.hidden = true;
      this.bindEvents();
    },

    getCredit: function() {
      if(app.debug) console.log("getCredit()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "getCredit()";
      var val = document.getElementById('residualCredit').value;
      if(app.localDebug) document.getElementById('msg').innerHTML = 'credit = € ' + val;
      document.getElementById('credits').innerHTML = '<i>' + val + '</i>';
      var val1 = document.getElementById('minimumCredit').value;
      if(app.localDebug) document.getElementById('msg').innerHTML = 'credit = € ' + val1;
      document.getElementById('minCredit').innerHTML = '<i>' + val1 + '</i>';
    },
 
    bindEvents: function() {
      if(app.debug) console.log("bindEvents()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "bindEvents()";
      document.addEventListener('deviceready', this.onDeviceReady, false);
      openInfo.addEventListener('touchend', this.openInfoPage, false); // touchstart
      openInstr.addEventListener('touchend', this.openInstrPage, false);
      openBEnd.addEventListener('touchend', this.openDataPage, false);
      openURL.addEventListener('touchend', this.tappedImage, false);
      retHome1.addEventListener('touchend', this.openHomePage, false);
      retHome2.addEventListener('touchend', this.openHomePage, false);
      retHome3.addEventListener('touchend', this.openHomePage, false);
      scanButton.addEventListener('touchend', this.advScanFunc, false);
    },

    advScanFunc: function () {
      if(app.debug) console.log("advScan Func()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "advScan Func()"; 
      ble.stopScan();
      ble.startScan([], app.onAdvDevice, app.onError);
      app.advTimer = setTimeout(app.endScan, 30000);
    },

    onDeviceReady: function() {
      if(app.debug) console.log("onDeviceReady()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "onDeviceReady()";
      window.open = cordova.InAppBrowser.open;
      app.refreshDeviceList();
    },

    tappedImage: function() {
      if(app.debug) console.log("tappedImage()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "tappedImage()";
      var ref = window.open('http://www.myparking.it', '_blank', 'location=yes');
    },
    
    //======================================================================================
    onError: function(reason) {
      if(app.debug) console.log("onError()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "onError()";
      alert("ERROR: " + reason); // real apps should use notification.alert
      app.refreshDeviceList();
    },
    
    //======================================================================================
    endScan: function() {
      if(app.debug) console.log("endScan()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "endScan()";
      ble.stopScan();
      navigator.vibrate(400);
    },
    
    openInfoPage: function() {
      if(app.debug) console.log("openInfoPage()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "openInfoPage()";
      homePage.hidden = true;
      infoPage.hidden = false;
      docPage.hidden = true;
      dataPage.hidden = true;
    },

    openInstrPage: function() {
      if(app.debug) console.log("openInstrPage()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "openInstrPage()";
      homePage.hidden = true;
      infoPage.hidden = true;
      docPage.hidden = false;
      dataPage.hidden = true;
    },

    openDataPage: function() {
      if(app.debug) console.log("openDataPage()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "openDataPage()";
      homePage.hidden = true;
      infoPage.hidden = true;
      docPage.hidden = true;
      dataPage.hidden = false;
    },

    openHomePage: function() {
      if(app.debug) console.log("openHomePage()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "openHomePage()";
      homePage.hidden = false;
      infoPage.hidden = true;
      docPage.hidden = true;
      dataPage.hidden = true;
      app.getCredit();
    },

    refreshDeviceList: function() {
      if(app.debug) console.log("refreshDeviceList()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "refreshDeviceList()";
      app.openHomePage();  
      scanDeviceList.innerHTML = '';
      document.getElementById('msg').innerHTML = '';
      document.getElementById('msg2').innerHTML = '';
      clearInterval(app.advTimer);
      ble.stopScan();
      ble.scan([], 16, app.onDiscoverDevice, app.onError);
    },

    onDiscoverDevice: function(device) {
      if(app.debug) console.log("onDiscoverDevice()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "onDiscoverDevice()";
      if(app.debug) console.log(JSON.stringify(device));
      if(app.localDebug) document.getElementById('msg').innerHTML = (JSON.stringify(device));
      if(device.name.match(/iBLio i6216/i)) {
        app.listItem = document.createElement('li'),
            html = '<b>' + device.name + '</b><br/>' +
                'RSSI: ' + device.rssi + '&nbsp;&nbsp;[' + device.id + ']';
        app.listItem.dataset.deviceId = device.id;
        app.listItem.innerHTML = html;
        scanDeviceList.appendChild(app.listItem);
      }
    },

    //======================================================================================
    tappedList: function(e) {
      if(app.debug) console.log("tappedList()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "tappedList()";
      app.advMAC = e.target.dataset.deviceId;
      if(app.debug) console.log(app.advMAC);
      document.getElementById('msg').innerHTML = '';
      var tapDisplay = document.getElementById("tapDisplay").checked;
      if(app.debug) console.log(tapDisplay);
      if(app.advMAC == null) {
        document.getElementById('msg').innerHTML = '<p><b>Please (re)Tap the Device on the List</b></p>';
      }
      else {
        document.getElementById('msg2').innerHTML = '<p><b>Connecting... Please wait</b></p>';
      }

      app.connect();
    },

    //======================================================================================
    advData: function() {
      if(app.debug) console.log("advData()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "advData()";
      homePage.hidden = true;
      infoPage.hidden = false;
      docPage.hidden = true;
      dataPage.hidden = true;
      app.advItem = document.getElementById("aMAC").innerHTML = app.advMAC; 
      ble.startScan([], app.onAdvDevice, app.onError);
      app.advTimer = setTimeout(advScanFunc, 600); 
    },

    onAdvDevice: function(device) {
      if(app.debug) console.log("onAdvDevice()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "onAdvDevice()";
      if(app.debug) console.log(JSON.stringify(device));
      if(app.localDebug) document.getElementById('msg').innerHTML = (JSON.stringify(device));
      if(device.id === app.advMAC) {
        // console.log( new Date() );
        // console.log(device.advertising); 

        var ios_dev_adv = device.advertising.kCBAdvDataManufacturerData;
        // console.log(ios_dev_adv); // 'null' for Android, 'Buffer' for iOS 
        if (ios_dev_adv == null) {
          // Android
          var pkt = new Uint8Array(device.advertising, 5, 25);
        }
        else {
          // iOS
          var pkt = new Uint8Array(ios_dev_adv);
        }
        // console.log(pkt);  
        if(pkt[0] == 0xFF) {
          if(pkt[1] == 0xFF) {
            if(pkt[2] == 0x5A) {
              advList.innerHTML = '';

              var ain0 = ((pkt[9] + (pkt[10] * 256)) * app.k0) + app.minAIN0um; 
              var a0 = Number(ain0).toFixed(2);
              app.advItem = document.createElement('li'), html = "AIN0&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + a0 + "&nbsp;&nbsp;" + app.AIN0um;
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);

              var ain1 = ((pkt[11] + (pkt[12] * 256)) * app.k1) + app.minAIN1um;
              var a1 = Number(ain1).toFixed(2);
              app.advItem = document.createElement('li'), html = "AIN1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + a1 + "&nbsp;&nbsp;" + app.AIN1um;
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);
              
              app.a = ((pkt[6] & 0x10) >> 4);
              (app.a == 1) ? app.b = "Off" : app.b = "On";
              app.advItem = document.createElement('li'), html = "DCIN0&nbsp;&nbsp;&nbsp;" + app.a + "&nbsp;&nbsp;" + app.b + "&nbsp;&nbsp;&nbsp;&nbsp;counter&nbsp;&nbsp;" + (pkt[17] + (pkt[18] * 256));
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);

              app.a = ((pkt[6] & 0x20) >> 5);
              (app.a == 1) ? app.b = "Off" : app.b = "On";
              app.advItem = document.createElement('li'), html = "DCIN1&nbsp;&nbsp;&nbsp;" + app.a + "&nbsp;&nbsp;" + app.b + "&nbsp;&nbsp;&nbsp;&nbsp;counter&nbsp;&nbsp;" + (pkt[19] + (pkt[20] * 256));
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);

              app.a = ((pkt[8] & 0x02) >> 1);
              (app.a == 1) ? app.b = "Off" : app.b = "On";
              app.advItem = document.createElement('li'), html = "BTN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + app.a + "&nbsp;&nbsp;" + app.b;
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);

              app.a = ((pkt[8] & 0x04) >> 2);
              (app.a == 1) ? app.b = "Off" : app.b = "On";
              app.advItem = document.createElement('li'), html = "LED1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + app.a + "&nbsp;&nbsp;" + app.b;
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);

              app.a = (pkt[8] & 0x01);
              (app.a == 1) ? app.b = "Off" : app.b = "On";
              app.advItem = document.createElement('li'), html = "LED2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + a + "&nbsp;&nbsp;" + b;
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);

              app.a = (pkt[7] & 0x01);
              (app.a == 0) ? app.b = "Off" : app.b = "On";
              app.advItem = document.createElement('li'), html = "RELAY&nbsp;&nbsp;&nbsp;" + app.a + "&nbsp;&nbsp;" + app.b;
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);
              
              app.a = ((pkt[7] & 0x04) >> 2);
              app.advItem = document.createElement('li'), html = "OUT0&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +  app.a + "&nbsp;&nbsp;" + app.b;
              app.advItem.innerHTML = html;
              advList.appendChild(app.advItem);
            }
          }
        }
      }
    },

    //======================================================================================
    connect: function() {
      if(app.debug) console.log("connect()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "connect()";
      onConnect = function() {
        if(app.debug) console.log("Connected...");
        if(app.localDebug) document.getElementById('msg').innerHTML = "connected...()";
        homePage.hidden = true;
        infoPage.hidden = true;
        docPage.hidden = false;
        dataPage.hidden =  false;
      };
      app.advItem = document.getElementById("cMAC").innerHTML = app.advMAC; 
      ble.connect(app.advMAC, onConnect, app.onError);
    },

    disconnect: function(e) {
      if(app.debug) console.log("disconnect()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "ondisconnect()";
      var html;

      app.AIN0um = document.getElementById("AIN0_um").value;
      app.minAIN0um = document.getElementById("minScaled_AIN0").value;
      app.maxAIN0um = document.getElementById("maxScaled_AIN0").value;
      app.k0 = (app.maxAIN0um - app.minAIN0um) / 2048;
      html = app.AIN0um + " " + app.minAIN0um + " " + app.maxAIN0um + " " + app.k0; 
      if(app.debug) console.log(html);

      app.AIN1um = document.getElementById("AIN1_um").value;
      app.minAIN1um = document.getElementById("minScaled_AIN1").value;
      app.maxAIN1um = document.getElementById("maxScaled_AIN1").value;
      app.k1 = (app.maxAIN1um - app.minAIN1um) / 2048;
      html = app.AIN1um + " " + app.minAIN1um + " " + app.maxAIN1um + " " + app.k1;
      if(app.debug) console.log(html);

      ble.disconnect(app.advMAC, app.refreshDeviceList, app.onError); 
    },

    set_LED1: function() {
      if(app.debug) console.log("Set_LED1()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "set_LED1()";
      var val = new Uint8Array(2);
      app.value = document.getElementById("LED1").value & 0xFFFF;
      val[1] = app.value >> 8;
      val[0] = app.value & 0xFF;
      ble.write(app.advMAC, app.node.service, app.node.led1, val.buffer, 
                function() { console.log(value); },app.onError);
    },

    set_LED2: function() {
      if(app.debug) console.log("Set_LED2()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "set_LED2()";
      var val = new Uint8Array(2);
      app.value = document.getElementById("LED2").value & 0xFFFF;
      val[1] = app.value >> 8;
      val[0] = app.value & 0xFF;
      ble.write(app.advMAC, app.node.service, app.node.led2, val.buffer, 
                function() { console.log(value); },app.onError);
    },

    set_RELAY: function() {
      if(app.debug) console.log("Set_RELAY()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "set_RELAY()";
      var val = new Uint8Array(2);
      app.value = document.getElementById("RELAY").value & 0xFFFF;
      val[1] = app.value >> 8;
      val[0] = app.value & 0xFF;
      ble.write(app.advMAC, app.node.service, app.node.relay, val.buffer, 
                function() { console.log(value); },app.onError);
    },

    set_OUT0: function() {
      if(app.debug) console.log("Set_OUT0()");
      if(app.localDebug) document.getElementById('msg').innerHTML = "set_OUT0()";
      var val = new Uint8Array(2);
      app.value = document.getElementById("OUT0").value & 0xFFFF;
      val[1] = app.value >> 8;
      val[0] = app.value & 0xFF;
      ble.write(app.advMAC, app.node.service, app.node.out0, val.buffer, 
                function() { console.log(value); },app.onError);
    }

};